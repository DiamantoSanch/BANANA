let burger = document.querySelector(".burger-menu")
let nav = document.querySelector(".main-nav")
burger.addEventListener("click", function() {
    burger.classList.toggle("active")
    nav.classList.toggle("active")
})

$('.carusel').slick({
  dots: false,
  arrows: false,
  infinite: true,
  speed: 750,
  slidesToShow: 1,
  adaptiveHeight: false,
  autoplay: true,
  autoplaySpeed: 5000
});